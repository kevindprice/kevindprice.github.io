Title: Experiments with the React Framework
Date: 08/31/17
Category: Web Design
Tags: Computer Modeling, React, JavaScript
Slug: react
Authors: Kevin Price
<!-- Summary:  -->

I decided to create a React web app to demonstrate the Coriolis effect. This [new React model](./CoriolisReact/index.html) is much cleaner and more powerful than my previous version, which I have removed from this site.

I am very pleased with the result. As you can see, the Coriolis effect has provided me ample material for creativity. The following article describes some of the steps I took to generate this model.

<!-- PELICAN_END_SUMMARY -->

###Coding goals

The Coriolis effect is an object of fascination of mine. As I stated in my article, the Coriolis effect is an artifact of rotating environments (artificial gravity) that causes objects to move in unexpected directions. With my physics experience, I had the knowledge and equations I needed to build this model.

My goal was to take this complicated physics principle and simplify it so that anyone can understand it. I wanted the model to be powerful enough to be able to render whatever throw a user wishes to model. With this objective, I hoped to make the effects of artificial gravity perfectly clear. Furthermore, I wanted the page to be compelling, clean, intuitive, understandable, beautiful, fast, resizable, mobile-friendly, and not glitchy.

###Steps to produce the model

This model came about in several stages. Though this came from a simple idea, the final result is much more sophisticated and powerful than what I had initially planned.

1. The first stage of this model was to calculate the landing position of the coin. The model should *compute* these coordinates for the viewer. Essentially, I needed to find the correct intersection between a line and a circle. The direction of this line is based on physics kinematics equations. [This](./coriolis-math.html) is the math I used.

2. With the landing coordinates, I could calculate the distance the coin would land away from the person; this is the measurable result of the Coriolis effect. I used this math [in Python](images/CoriolisTable.py) to generate a graph that shows the relationship between the diameter of the station and the "weirdness" of the throw produced by the Coriolis effect. These graphs assume the coin was tossed from four feet, up to a total height of 7 feet.

3. I wanted to demonstrate what any throw would *look* like. Using the line of the coin's movement, I generated a time series of points, allowing me to plot these points on an HTML canvas element.

4. These points needed to be in the *thrower's* reference frame, not the frame of the outside universe. This is the only way the Coriolis effect would be clearly demonstrated. This required me to translate my series of points into a new set of points that are *relative* to the thrower. This required writing out more equations and solving a bit of trigonometry.

5. I wrote [an article](./Coriolis.html) about the Coriolis effect. I wanted this article to be complete, informative, and entertaining.

6. Next, I wanted to improve the model's UI to make it clean and professional. I rewrote the model to utilize the React framework. I added intuitive logarithmic sliders (that include the number zero!) so that it would be easy to change the throw's parameters.

7. I continued debugging the code and adding more use cases.

8. I added the article overtop the model in a way that users can easily jump between the two.


###Some things I encountered while coding

#####Logarithmic Sliders

I wanted to produce logarithmic sliders for the model's input. This way, it would be intuitive what ranges are acceptable. I found the logic I needed at [this site](https://codepen.io/willat600series/pen/ojzYJx).

My logarithmic ranges needed to *include* zero; the log of zero does not normally compute. I added a small offset from the numbers that are visible so that the value calculated is never actually zero.

#####Insufficient Decimal Places

I discovered that the standard decimal variable in Python and JavaScript is not accurate enough to calculate the results that I desired. Fifteen decimal places produces glitchy results with large "space stations." Thus, I translated all of my math to work with the Decimal.js JavaScript library and the Python Decimal package. Then, I increased the number of decimal places so I could model larger space stations.

Here is my glitchy graph with the standard number of decimal places. You may note that the graph never actually achieves the values expected with stations that are larger than 1*10^7 meters:

<img style="margin: 5px 0px 5px 0px;" src="images/CoriolisGraphGlitchy.png" width="525" height="525"/>

With additional decimal places:

<img style="margin: 5px 0px 5px 0px;" src="images/CoriolisGraph.png" width="525" height="525"/>

The Python code I used to generate these graphs can be found [here](images/CoriolisTable.py).

In JavaScript, the current version of the Decimal.js package does not work with webpack. Thus, in order to use the model with React, I needed to downgrade the package. This issue is discussed [here](https://github.com/MikeMcl/decimal.js/issues/49).

#####A Resizeable React canvas

I wanted the model to be compatible with any screen size presented to it. Thus, I wanted to create an HTML canvas element that both fills the screen width and resizes. The canvas must receive its with from the properties, not from CSS. 

[This React plugin](https://www.npmjs.com/package/react-container-dimensions) initially looked like it would do the job, but it proved useless. Canvas elements must be connected to React refs in order to obtain the drawing context from ReactDOM. This is not possible with functional components, which the react-container-dimensions plugin uses.

I ultimately created an event listener in the Canvas component which triggers a state change when the window is resized. The Canvas then inherits its width and height attributes from the component's state.